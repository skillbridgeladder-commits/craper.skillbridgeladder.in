# How to Protect Your Skill Scraper Code

Since JavaScript (used in the Chrome Extension and Next.js) is naturally visible to users, you should take steps to "Obfuscate" it before distribution to prevent people from stealing your code.

## 1. Obfuscate the Chrome Extension
The extension code is the most vulnerable. Before zipping it up, follow these steps:
1.  **Use Javascript Obfuscator**: Go to [javascript-obfuscator.com](https://javascript-obfuscator.com/).
2.  **Files to Obfuscate**: 
    - `contentScript.js` (The most valuable code)
    - `js/popup.js`
    - `auth/supabase-config.js`
3.  **Settings**: Use "High" or "Medium" obfuscation. This makes the code unreadable to humans but functional for Chrome.
4.  **Replace**: Replace your original files with the obfuscated versions before creating your final `skill-scraper.zip`.

## 2. Minification
For the Next.js dashboard, Vercel and Next.js already **minify** and **bundle** your code during the `npm run build` process. This makes the code very hard to read for outsiders.

## 3. Supabase Security (Already Done ✅)
I have already set up **Row Level Security (RLS)** in your database. This means even if someone gets your `anon_key`, they **cannot** see other users' data or upgrade themselves without your admin approval.

## 4. Terms of Service
Add a "Terms of Service" page to your website stating that reverse engineering is prohibited (covered in the `LICENSE.md` I created).
