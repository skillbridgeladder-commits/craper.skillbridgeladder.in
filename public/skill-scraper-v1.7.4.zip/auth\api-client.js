// API client for Skill Scraper Extension
// Uses config.dashboardUrl from config.js (e.g., https://scraper.skillbridgeladder.in)

async function getToken() {
    return new Promise((resolve) => {
        chrome.storage.sync.get(['ext_token'], function (result) {
            resolve(result.ext_token);
        });
    });
}

function isLoggedIn() {
    return getToken().then(token => !!token);
}

function logout() {
    return new Promise((resolve) => {
        chrome.storage.sync.remove(['ext_token', 'ext_user_plan', 'ext_enterprise_key'], function () {
            resolve();
        });
    });
}

// Cache plan locally so we don't hit the API every scrape
async function getCachedPlan() {
    return new Promise((resolve) => {
        chrome.storage.sync.get(['ext_user_plan', 'ext_plan_fetched_at'], function (result) {
            const plan = result.ext_user_plan;
            const fetchedAt = result.ext_plan_fetched_at || 0;
            const age = Date.now() - fetchedAt;
            // Cache for 5 seconds instead of 5 minutes to allow near real-time sync
            if (plan && age < 5000) {
                resolve(plan);
            } else {
                resolve(null);
            }
        });
    });
}

async function savePlanCache(plan) {
    return new Promise((resolve) => {
        chrome.storage.sync.set({
            ext_user_plan: plan,
            ext_plan_fetched_at: Date.now()
        }, resolve);
    });
}

async function apiGetPlan() {
    const token = await getToken();
    if (!token) throw new Error("Not logged in");

    // Check cache first
    const cached = await getCachedPlan();
    if (cached) return cached;

    const res = await fetch(`${config.dashboardUrl}/api/ext/plan`, {
        method: 'GET',
        headers: {
            'Authorization': `Bearer ${token}`
        }
    });

    if (!res.ok) {
        if (res.status === 401) {
            await logout();
            throw new Error("Session expired. Please login again.");
        }
        throw new Error("Failed to fetch plan info");
    }

    const plan = await res.json();
    await savePlanCache(plan);
    return plan;
}

async function apiUpdateUsage(count) {
    const token = await getToken();
    if (!token) return; // silently skip if not logged in

    const res = await fetch(`${config.dashboardUrl}/api/ext/usage`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ count })
    });

    if (res.ok) {
        // Update local cache
        const cached = await getCachedPlan();
        if (cached) {
            cached.used = (cached.used || 0) + count;
            await savePlanCache(cached);
        }
    } else {
        console.error("Failed to update usage", await res.text());
    }
}

// Enterprise Key activation
async function apiActivateKey(keyCode) {
    const token = await getToken();
    if (!token) throw new Error("Not logged in");

    const res = await fetch(`${config.dashboardUrl}/api/ext/activate-key`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ key_code: keyCode })
    });

    const data = await res.json();
    if (!res.ok) {
        throw new Error(data.error || 'Key activation failed');
    }

    // Clear plan cache so it refreshes
    await new Promise(r => chrome.storage.sync.remove(['ext_user_plan', 'ext_plan_fetched_at'], r));
    // Save key
    await new Promise(r => chrome.storage.sync.set({ ext_enterprise_key: keyCode }, r));

    return data;
}

// Check if user has remaining credits
async function checkCreditsAvailable() {
    try {
        const token = await getToken();
        if (!token) return true; // Guest mode, handled by guest limit

        const plan = await apiGetPlan();
        if (!plan) return true;

        // Enterprise keys or unlimited plans
        if (plan.plan === 'enterprise') return true;

        const remaining = (plan.quota || 200) - (plan.used || 0);
        if (remaining <= 0) {
            return false;
        }
        return true;
    } catch (e) {
        console.error("checkCreditsAvailable error:", e);
        return true; // Allow on error to not block users
    }
}

// Global functions matching old signatures (for backwards compatibility)

async function getCurrentUser() {
    const token = await getToken();
    if (!token) return null;
    try {
        const base64Url = token.split('.')[1];
        const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
        const jsonPayload = decodeURIComponent(atob(base64).split('').map(function (c) {
            return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
        }).join(''));
        const payload = JSON.parse(jsonPayload);

        // Check token expiry
        if (payload.exp && payload.exp * 1000 < Date.now()) {
            // Token expired, clear it
            await logout();
            return null;
        }

        return { email: payload.email, id: payload.sub };
    } catch (e) {
        return null;
    }
}

async function getUserPlan() {
    try {
        return await apiGetPlan();
    } catch (e) {
        console.error("getUserPlan error:", e);
        return null;
    }
}

async function updateUsage(count) {
    try {
        await apiUpdateUsage(count);
    } catch (e) {
        console.error("updateUsage error:", e);
    }
}

async function signOut() {
    await logout();
}
