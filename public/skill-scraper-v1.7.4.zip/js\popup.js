// Skill Scraper - Popup Script
// No login required for scraping, login needed for export

document.addEventListener('DOMContentLoaded', async function () {
    // --- Auth UI Elements ---
    const loginBtn = document.getElementById('loginBtn');
    const authArea = document.getElementById('authArea');
    const userInfoBar = document.getElementById('userInfoBar');
    const enterpriseKeySection = document.getElementById('enterpriseKeySection');

    // --- Auth Tabs ---
    document.querySelectorAll('.ss-tab').forEach(tab => {
        tab.addEventListener('click', function () {
            document.querySelectorAll('.ss-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            const isLogin = this.dataset.tab === 'login';
            document.getElementById('loginForm').style.display = isLogin ? 'flex' : 'none';
            document.getElementById('signupForm').style.display = isLogin ? 'none' : 'flex';
        });
    });

    // --- Login ---
    loginBtn.addEventListener('click', function () {
        chrome.tabs.create({ url: DASHBOARD_URL + "/login?ext=true" }, function (tab) {
            setTimeout(() => {
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    files: ["lcs.js"]
                }).catch(e => console.log("lcs.js inject retry later:", e));
            }, 2000);
        });
    });

    // --- Update Auth UI ---
    async function updateAuthUI() {
        try {
            const user = await getCurrentUser();
            if (user) {
                // Logged in
                authArea.innerHTML = `
                    <span class="ss-user-name">${user.email.split('@')[0]}</span>
                    <button id="logoutBtn" class="ss-btn ss-btn-ghost ss-btn-sm">Logout</button>
                `;
                document.getElementById('logoutBtn').addEventListener('click', async () => {
                    await signOut();
                    window.location.reload();
                });

                userInfoBar.style.display = 'flex';
                document.getElementById('userEmail').textContent = user.email;

                // Get plan info from dashboard API
                const plan = await getUserPlan();
                if (plan) {
                    const planConfig = PLANS[plan.plan] || PLANS.free;
                    document.getElementById('planBadge').textContent = planConfig.name;
                    document.getElementById('planBadge').className = 'ss-plan-badge ss-plan-' + plan.plan;
                    const remaining = plan.quota - (plan.used || 0);
                    document.getElementById('usageInfo').textContent =
                        plan.plan === 'enterprise' ? '∞ Unlimited exports' :
                            `${remaining.toLocaleString()} / ${plan.quota.toLocaleString()} credits`;

                    // Show upgrade link if not enterprise
                    if (plan.plan !== 'enterprise') {
                        document.getElementById('upgradeLink').style.display = 'flex';
                        document.getElementById('rewardAdBtn').style.display = 'flex';
                        // Show enterprise key section
                        enterpriseKeySection.style.display = 'block';
                    } else {
                        // Enterprise — show key info
                        enterpriseKeySection.style.display = 'block';
                        document.getElementById('keyInput').style.display = 'none';
                        document.getElementById('activateKeyBtn').style.display = 'none';
                        document.getElementById('keyMsg').textContent = '✅ Enterprise key active';
                        document.getElementById('keyMsg').style.color = '#22c55e';
                    }
                }
            } else {
                // Not logged in
                document.getElementById('upgradeLink').style.display = 'none';
                enterpriseKeySection.style.display = 'none';
            }
        } catch (e) {
            console.log('Auth UI update error:', e);
        }
    }

    // --- Enterprise Key Activation ---
    document.getElementById('activateKeyBtn').addEventListener('click', async function () {
        const keyInput = document.getElementById('keyInput');
        const keyMsg = document.getElementById('keyMsg');
        const keyCode = keyInput.value.trim();

        if (!keyCode) {
            keyMsg.textContent = '❌ Please enter a key';
            keyMsg.style.color = '#ef4444';
            return;
        }

        this.disabled = true;
        this.textContent = '...';
        keyMsg.textContent = '';

        try {
            const result = await chrome.runtime.sendMessage({ action: "activateKey", keyCode: keyCode });
            if (result.success) {
                keyMsg.textContent = '✅ ' + (result.message || 'Enterprise key activated!');
                keyMsg.style.color = '#22c55e';
                // Refresh UI
                setTimeout(() => window.location.reload(), 1500);
            } else {
                keyMsg.textContent = '❌ ' + (result.error || 'Activation failed');
                keyMsg.style.color = '#ef4444';
            }
        } catch (e) {
            keyMsg.textContent = '❌ Error: ' + e.message;
            keyMsg.style.color = '#ef4444';
        }

        this.disabled = false;
        this.textContent = 'Activate';
    });

    // --- Initialize auth UI ---
    await updateAuthUI();

    // --- Search Button ---
    document.getElementById('addprofilebtn').addEventListener('click', function () {
        let query = document.getElementById('profileid').value.trim();
        const country = document.getElementById('countrySelect').value;
        const state = document.getElementById('stateInput').value.trim();
        const city = document.getElementById('cityInput').value.trim();

        const locationParts = [];
        if (city) locationParts.push(city);
        if (state) locationParts.push(state);
        if (country) locationParts.push(country);

        if (locationParts.length > 0) {
            query += ' in ' + locationParts.join(', ');
        }

        const encoded = encodeURIComponent(query);
        window.open(`https://www.google.com/maps/search/${encoded}`);
    });

    // --- Demo Link ---
    document.getElementById('demo_link').addEventListener('click', function (e) {
        e.preventDefault();
        chrome.tabs.create({ url: 'demo.html' });
    });

    // --- Video Link ---
    document.getElementById('demo_video').addEventListener('click', function (e) {
        e.preventDefault();
        chrome.tabs.create({ url: 'https://youtu.be/svsDoqsBt8s' });
    });

    // --- Upgrade Link ---
    document.getElementById('upgradeLink').addEventListener('click', function (e) {
        e.preventDefault();
        chrome.tabs.create({ url: DASHBOARD_URL + '/upgrade' });
    });

    // --- Rewarded Ad Logic ---
    const rewardAdBtn = document.getElementById('rewardAdBtn');
    const adOverlay = document.getElementById('adOverlay');
    const adTimerText = document.getElementById('adTimerText');
    const adCountdown = document.getElementById('adCountdown');
    const adCloseBtn = document.getElementById('adCloseBtn');

    let isAdPlaying = false;
    let rewardGranted = false;

    rewardAdBtn.addEventListener('click', function (e) {
        e.preventDefault();
        if (isAdPlaying) return;

        isAdPlaying = true;
        rewardGranted = false;

        // Reset overlay state
        adOverlay.style.display = 'flex';
        adCloseBtn.style.display = 'none';
        adTimerText.innerHTML = 'Reward in <span id="adCountdown">10</span> seconds...';

        let timeLeft = 10;
        const countdownSpan = document.getElementById('adCountdown');

        const timerId = setInterval(async () => {
            timeLeft--;
            if (countdownSpan) countdownSpan.textContent = timeLeft;

            if (timeLeft <= 0) {
                clearInterval(timerId);
                adTimerText.innerHTML = '<span style="color:#22c55e;">Granting Reward...</span>';

                try {
                    // Call backend API to grant reward
                    const token = await apiClient.getToken();
                    if (!token) throw new Error("Not authenticated");

                    const response = await fetch(DASHBOARD_URL + '/api/ext/reward', {
                        method: 'POST',
                        headers: {
                            'Authorization': 'Bearer ' + token,
                            'Content-Type': 'application/json'
                        }
                    });

                    const result = await response.json();

                    if (response.ok) {
                        adTimerText.innerHTML = `<span style="color:#22c55e; font-weight:bold;">${result.message}</span>`;
                        rewardGranted = true;

                        // Update UI seamlessly
                        setTimeout(() => updateAuthUI(), 500);
                    } else {
                        throw new Error(result.error);
                    }
                } catch (err) {
                    console.error("Reward error:", err);
                    adTimerText.innerHTML = `<span style="color:#ef4444;">Failed to grant reward.</span>`;
                }

                // Show close button
                adCloseBtn.style.display = 'block';
                isAdPlaying = false;
            }
        }, 1000);
    });

    // Close Ad Overlay
    adCloseBtn.addEventListener('click', function () {
        if (!isAdPlaying) {
            adOverlay.style.display = 'none';
        }
    });

});
