// cookie_page.js — Database-synced Cookie Viewer with performance optimizations
// Requires: auth/config.js and auth/api-client.js loaded before this script

// ══════════════════════════════════════════════════════════
//  IndexedDB Cache Layer (stale-while-revalidate)
// ══════════════════════════════════════════════════════════

const CookieDB = (() => {
  const DB_NAME = 'CookieViewerCache';
  const DB_VERSION = 1;
  const STORE = 'cookies';

  function openDB() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains(STORE)) {
          db.createObjectStore(STORE, { keyPath: 'id' });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }

  return {
    async save(cookies) {
      try {
        const db = await openDB();
        const tx = db.transaction(STORE, 'readwrite');
        const store = tx.objectStore(STORE);
        store.put({ id: 'latest', data: cookies, timestamp: Date.now() });
        return new Promise((resolve, reject) => {
          tx.oncomplete = resolve;
          tx.onerror = () => reject(tx.error);
        });
      } catch (e) {
        console.warn('IndexedDB save error:', e);
      }
    },

    async load() {
      try {
        const db = await openDB();
        const tx = db.transaction(STORE, 'readonly');
        const store = tx.objectStore(STORE);
        const req = store.get('latest');
        return new Promise((resolve) => {
          req.onsuccess = () => resolve(req.result || null);
          req.onerror = () => resolve(null);
        });
      } catch (e) {
        console.warn('IndexedDB load error:', e);
        return null;
      }
    },

    async saveLastSync(snapshot) {
      try {
        const db = await openDB();
        const tx = db.transaction(STORE, 'readwrite');
        const store = tx.objectStore(STORE);
        store.put({ id: 'lastSync', data: snapshot, timestamp: Date.now() });
        return new Promise((resolve, reject) => {
          tx.oncomplete = resolve;
          tx.onerror = () => reject(tx.error);
        });
      } catch (e) {
        console.warn('IndexedDB saveLastSync error:', e);
      }
    },

    async loadLastSync() {
      try {
        const db = await openDB();
        const tx = db.transaction(STORE, 'readonly');
        const store = tx.objectStore(STORE);
        const req = store.get('lastSync');
        return new Promise((resolve) => {
          req.onsuccess = () => resolve(req.result || null);
          req.onerror = () => resolve(null);
        });
      } catch (e) {
        return null;
      }
    }
  };
})();


// ══════════════════════════════════════════════════════════
//  Sync Status UI
// ══════════════════════════════════════════════════════════

const SyncUI = {
  indicator: null,
  label: null,
  timeEl: null,
  syncBtn: null,

  init() {
    this.indicator = document.getElementById('sync-indicator');
    this.label = document.getElementById('sync-label');
    this.timeEl = document.getElementById('sync-time');
    this.syncBtn = document.getElementById('btn-sync');
  },

  setState(state, message) {
    if (!this.indicator) return;
    this.indicator.className = 'sync-indicator ' + state;
    this.label.textContent = message || state;
    if (this.syncBtn) {
      this.syncBtn.disabled = (state === 'syncing');
    }
  },

  setTime(ts) {
    if (!this.timeEl) return;
    if (!ts) {
      this.timeEl.textContent = '';
      return;
    }
    const d = new Date(ts);
    const now = Date.now();
    const diff = now - ts;
    let ago;
    if (diff < 5000) ago = 'just now';
    else if (diff < 60000) ago = Math.floor(diff / 1000) + 's ago';
    else if (diff < 3600000) ago = Math.floor(diff / 60000) + 'm ago';
    else ago = d.toLocaleTimeString();
    this.timeEl.textContent = 'Last sync: ' + ago;
  }
};


// ══════════════════════════════════════════════════════════
//  Database Sync (via background service worker)
// ══════════════════════════════════════════════════════════

const CookieSync = {
  _debounceTimer: null,
  _lastSyncHash: null,

  // Generate a lightweight hash of cookie data to detect changes
  _hash(cookies) {
    const str = cookies.map(c => c.domain + '|' + c.name + '|' + c.value).sort().join('\n');
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const ch = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + ch;
      hash |= 0; // Convert to 32-bit integer
    }
    return hash;
  },

  // Diff-based: compute added/removed/changed cookies vs last sync
  _computeDiff(current, lastSnapshot) {
    if (!lastSnapshot || !lastSnapshot.length) {
      return { full: true, cookies: current };
    }

    const lastMap = new Map();
    lastSnapshot.forEach(c => lastMap.set(c.domain + '::' + c.name + '::' + c.path, c));

    const currentMap = new Map();
    current.forEach(c => currentMap.set(c.domain + '::' + c.name + '::' + c.path, c));

    const added = [];
    const changed = [];
    const removed = [];

    // Find added & changed
    for (const [key, c] of currentMap) {
      const old = lastMap.get(key);
      if (!old) {
        added.push(c);
      } else if (old.value !== c.value || old.expirationDate !== c.expirationDate ||
                 old.secure !== c.secure || old.httpOnly !== c.httpOnly ||
                 old.sameSite !== c.sameSite) {
        changed.push(c);
      }
    }

    // Find removed
    for (const key of lastMap.keys()) {
      if (!currentMap.has(key)) {
        const c = lastMap.get(key);
        removed.push({ domain: c.domain, name: c.name, path: c.path });
      }
    }

    const hasChanges = added.length > 0 || changed.length > 0 || removed.length > 0;
    return { full: false, hasChanges, added, changed, removed };
  },

  async sync(cookies, force = false) {
    // Check if user is logged in
    let token;
    try {
      token = await getToken();
    } catch (e) {
      SyncUI.setState('offline', 'Not logged in');
      return;
    }
    if (!token) {
      SyncUI.setState('offline', 'Not logged in');
      return;
    }

    // Hash check — skip sync if nothing changed
    const currentHash = this._hash(cookies);
    if (!force && currentHash === this._lastSyncHash) {
      // No changes since last sync
      return;
    }

    SyncUI.setState('syncing', 'Syncing…');

    try {
      // Load last sync snapshot for diff
      const lastSync = await CookieDB.loadLastSync();
      const lastSnapshot = lastSync ? lastSync.data : null;
      const diff = this._computeDiff(cookies, lastSnapshot);

      let payload;
      if (diff.full) {
        payload = { type: 'full', cookies: cookies, timestamp: Date.now() };
      } else if (!diff.hasChanges) {
        // No actual changes — just update the sync time
        SyncUI.setState('synced', 'Synced ✓');
        SyncUI.setTime(Date.now());
        this._lastSyncHash = currentHash;
        return;
      } else {
        payload = {
          type: 'diff',
          added: diff.added,
          changed: diff.changed,
          removed: diff.removed,
          totalCount: cookies.length,
          timestamp: Date.now()
        };
      }

      // Send via background service worker for MV3 compatibility
      const response = await new Promise((resolve) => {
        chrome.runtime.sendMessage({ action: 'syncCookies', data: payload }, resolve);
      });

      if (response && response.success) {
        SyncUI.setState('synced', 'Synced ✓');
        SyncUI.setTime(Date.now());
        this._lastSyncHash = currentHash;
        // Save snapshot for next diff
        await CookieDB.saveLastSync(cookies);
      } else {
        const errMsg = response && response.error ? response.error : 'Sync failed';
        SyncUI.setState('error', errMsg);
        console.error('Cookie sync error:', errMsg);
      }
    } catch (e) {
      SyncUI.setState('error', 'Sync error');
      console.error('Cookie sync error:', e);
    }
  },

  // Debounced sync (2 second delay)
  debouncedSync(cookies) {
    clearTimeout(this._debounceTimer);
    this._debounceTimer = setTimeout(() => {
      this.sync(cookies);
    }, 2000);
  }
};


// ══════════════════════════════════════════════════════════
//  Cookie Fetching
// ══════════════════════════════════════════════════════════

async function fetchAllCookies() {
  // chrome.cookies API is only available in extension context (chrome-extension:// pages)
  if (typeof chrome === 'undefined' || !chrome.cookies || !chrome.cookies.getAll) {
    console.warn('chrome.cookies API not available — page must be opened as an extension page.');
    return null; // null signals "API unavailable" vs [] which means "no cookies"
  }
  const cookies = await chrome.cookies.getAll({});
  return cookies;
}


// ══════════════════════════════════════════════════════════
//  Grouping & Formatting
// ══════════════════════════════════════════════════════════

function groupByDomain(cookies) {
  const groups = {};
  cookies.forEach(c => {
    const domain = c.domain.replace(/^\./, '');
    if (!groups[domain]) groups[domain] = [];
    groups[domain].push(c);
  });
  // Sort domains alphabetically
  return Object.fromEntries(
    Object.entries(groups).sort(([a], [b]) => a.localeCompare(b))
  );
}

function formatExpiry(cookie) {
  if (cookie.session) return 'Session';
  if (!cookie.expirationDate) return 'Unknown';
  return new Date(cookie.expirationDate * 1000).toLocaleString();
}


// ══════════════════════════════════════════════════════════
//  Rendering (DocumentFragment-based, with lazy loading)
// ══════════════════════════════════════════════════════════

// Maximum number of domain groups to render immediately
const INITIAL_RENDER_LIMIT = 50;

function esc(s) {
  const d = document.createElement('div');
  d.textContent = String(s);
  return d.innerHTML;
}

function createDomainGroup(domain, domainCookies, startCollapsed = false) {
  const group = document.createElement('div');
  group.className = 'domain-group' + (startCollapsed ? ' collapsed' : '');

  // Header
  const header = document.createElement('div');
  header.className = 'domain-header';
  header.innerHTML = `
    <span class="arrow">▼</span>
    <strong>${esc(domain)}</strong>
    <span class="badge">${domainCookies.length}</span>
  `;
  header.addEventListener('click', function () {
    const g = this.parentElement;
    g.classList.toggle('collapsed');
    // Lazy render: build the table body on first expand
    if (!g.classList.contains('collapsed') && !g.dataset.rendered) {
      buildDomainTable(g, domainCookies);
      g.dataset.rendered = '1';
    }
  });
  group.appendChild(header);

  // Body container (empty shell — filled on expand or immediately if not collapsed)
  const body = document.createElement('div');
  body.className = 'domain-body';
  group.appendChild(body);

  // If not collapsed, render table immediately
  if (!startCollapsed) {
    buildDomainTable(group, domainCookies);
    group.dataset.rendered = '1';
  }

  return group;
}

function buildDomainTable(groupEl, domainCookies) {
  const body = groupEl.querySelector('.domain-body');
  if (!body) return;

  const table = document.createElement('table');
  const thead = document.createElement('thead');
  thead.innerHTML = `<tr><th>Name</th><th>Value</th><th>Path</th><th>Expires</th><th>Flags</th></tr>`;
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  const frag = document.createDocumentFragment();

  for (const c of domainCookies) {
    const tr = document.createElement('tr');

    const tdName = document.createElement('td');
    tdName.className = 'name-col';
    tdName.textContent = c.name;

    const tdValue = document.createElement('td');
    tdValue.className = 'value-col';
    tdValue.textContent = c.value;
    tdValue.title = c.value;

    const tdPath = document.createElement('td');
    tdPath.textContent = c.path;

    const tdExpiry = document.createElement('td');
    tdExpiry.textContent = formatExpiry(c);

    const tdFlags = document.createElement('td');
    let flagsHTML = '';
    if (c.secure) flagsHTML += '<span class="flag secure">Secure</span>';
    if (c.httpOnly) flagsHTML += '<span class="flag httponly">HttpOnly</span>';
    if (c.sameSite && c.sameSite !== 'unspecified')
      flagsHTML += `<span class="flag samesite">${esc(c.sameSite)}</span>`;
    tdFlags.innerHTML = flagsHTML;

    tr.appendChild(tdName);
    tr.appendChild(tdValue);
    tr.appendChild(tdPath);
    tr.appendChild(tdExpiry);
    tr.appendChild(tdFlags);
    frag.appendChild(tr);
  }

  tbody.appendChild(frag);
  table.appendChild(tbody);
  body.appendChild(table);
}

function renderCookies(cookies, filter = '') {
  const container = document.getElementById('cookies-container');
  const countEl = document.getElementById('total-count');
  const domainCountEl = document.getElementById('domain-count');

  let filtered = cookies;
  if (filter) {
    const q = filter.toLowerCase();
    filtered = cookies.filter(c =>
      c.domain.toLowerCase().includes(q) ||
      c.name.toLowerCase().includes(q) ||
      c.value.toLowerCase().includes(q)
    );
  }

  const grouped = groupByDomain(filtered);
  const domainKeys = Object.keys(grouped);
  const domainCount = domainKeys.length;

  countEl.textContent = filtered.length;
  domainCountEl.textContent = domainCount;

  if (filtered.length === 0) {
    container.innerHTML = '<div class="empty">No cookies found</div>';
    return;
  }

  // Build using DocumentFragment for minimal reflows
  const frag = document.createDocumentFragment();

  domainKeys.forEach((domain, idx) => {
    // Render first N groups expanded, rest collapsed (lazy) for performance
    const startCollapsed = idx >= INITIAL_RENDER_LIMIT;
    const group = createDomainGroup(domain, grouped[domain], startCollapsed);
    frag.appendChild(group);
  });

  container.innerHTML = '';
  container.appendChild(frag);
}

// Show skeleton placeholders while loading
function showLoadingSkeleton() {
  const container = document.getElementById('cookies-container');
  let html = '';
  for (let i = 0; i < 8; i++) {
    html += '<div class="skeleton-row"></div>';
  }
  container.innerHTML = html;
}


// ══════════════════════════════════════════════════════════
//  Export Functions
// ══════════════════════════════════════════════════════════

function exportJSON(cookies) {
  const data = JSON.stringify(cookies, null, 2);
  download(data, 'cookies_export.json', 'application/json');
}

function exportCSV(cookies) {
  const headers = 'Domain,Name,Value,Path,Expires,Secure,HttpOnly,SameSite\n';
  const rows = cookies.map(c =>
    [c.domain, c.name, `"${c.value.replace(/"/g, '""')}"`, c.path,
     formatExpiry(c), c.secure, c.httpOnly, c.sameSite || ''].join(',')
  ).join('\n');
  download(headers + rows, 'cookies_export.csv', 'text/csv');
}

function download(content, filename, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}


// ══════════════════════════════════════════════════════════
//  Debounce Utility
// ══════════════════════════════════════════════════════════

function debounce(fn, delay) {
  let timer;
  return function (...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
}


// ══════════════════════════════════════════════════════════
//  Init
// ══════════════════════════════════════════════════════════

let allCookies = [];

document.addEventListener('DOMContentLoaded', async () => {
  SyncUI.init();

  // 1. Load from IndexedDB cache first (instant render)
  showLoadingSkeleton();
  const cached = await CookieDB.load();
  if (cached && cached.data && cached.data.length > 0) {
    allCookies = cached.data;
    renderCookies(allCookies);
  }

  // 2. Load last sync timestamp
  const lastSync = await CookieDB.loadLastSync();
  if (lastSync && lastSync.timestamp) {
    SyncUI.setTime(lastSync.timestamp);
  }

  // 3. Fetch fresh cookies from browser (stale-while-revalidate)
  try {
    const freshCookies = await fetchAllCookies();
    if (freshCookies !== null) {
      // API available — use fresh data
      allCookies = freshCookies;
      renderCookies(allCookies);
      // Save to IndexedDB cache
      await CookieDB.save(allCookies);
      // Auto-sync to database
      CookieSync.debouncedSync(allCookies);
    } else if (allCookies.length === 0) {
      // API unavailable and no cached data
      document.getElementById('cookies-container').innerHTML =
        '<div class="empty">⚠️ chrome.cookies API not available.<br>Open this page from the extension (chrome-extension:// URL) to fetch cookies.<br>Showing cached data if available.</div>';
    }
    // else: API unavailable but we have cached data — already rendered above
  } catch (e) {
    console.error('Failed to fetch cookies:', e);
    if (allCookies.length === 0) {
      document.getElementById('cookies-container').innerHTML =
        '<div class="empty">Failed to load cookies. Make sure this page is running as an extension page.</div>';
    }
  }

  // Search with debounce (150ms)
  const debouncedSearch = debounce((value) => {
    renderCookies(allCookies, value);
  }, 150);

  document.getElementById('search').addEventListener('input', (e) => {
    debouncedSearch(e.target.value);
  });

  // Refresh button
  document.getElementById('btn-refresh').addEventListener('click', async () => {
    showLoadingSkeleton();
    const freshCookies = await fetchAllCookies();
    if (freshCookies !== null) {
      allCookies = freshCookies;
      await CookieDB.save(allCookies);
      CookieSync.debouncedSync(allCookies);
    }
    renderCookies(allCookies, document.getElementById('search').value);
  });

  // Manual sync button
  document.getElementById('btn-sync').addEventListener('click', async () => {
    if (allCookies.length === 0) return;
    await CookieSync.sync(allCookies, true); // force = true bypasses hash check
  });

  // Export buttons
  document.getElementById('btn-json').addEventListener('click', () => exportJSON(allCookies));
  document.getElementById('btn-csv').addEventListener('click', () => exportCSV(allCookies));

  // Periodically update the "last sync" relative time display
  setInterval(() => {
    CookieDB.loadLastSync().then(ls => {
      if (ls && ls.timestamp) SyncUI.setTime(ls.timestamp);
    });
  }, 30000);
});
