// Stub rolecheck for backward compatibility
// All auth is now handled by Supabase via supabase-config.js

async function rolecheck() {
    try {
        const plan = await getUserPlan();
        if (plan) {
            return {
                plan: plan.plan || 'free',
                quota: plan.quota || 200,
                used: plan.used || 0
            };
        }
    } catch (e) {
        console.log('rolecheck error:', e);
    }
    return { plan: 'free', quota: 200, used: 0 };
}

async function updateuse(count) {
    try {
        await updateUsage(count);
    } catch (e) {
        console.log('updateuse error:', e);
    }
}

// Legacy stubs (no-ops)
function login() { }
function upgradeToPro() {
    window.open(DASHBOARD_URL + '/upgrade');
}
function customerportal() {
    window.open(DASHBOARD_URL + '/dashboard');
}
