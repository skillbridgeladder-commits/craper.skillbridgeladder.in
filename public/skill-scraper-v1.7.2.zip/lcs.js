window.addEventListener("message", function (event) {
    if (event.data && event.data.type === "EXTENSION_LOGIN_SUCCESS") {
        const token = event.data.token;
        console.log("Captured login token from dashboard.");

        chrome.storage.sync.set({ ext_token: token }, function () {
            alert("Login Success! You can close this tab and open the extension.");
            // Tell background script that we logged in
            chrome.runtime.sendMessage({ action: "login_success" });
        });
    }
});
