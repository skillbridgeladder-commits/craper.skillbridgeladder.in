try {
    importScripts("auth/api-client.js");
    importScripts("auth/config.js");
    importScripts("auth/pay/rolecheck.js");
    importScripts("js/mybg.js");
    importScripts("sorry.js");
} catch (a) {
    console.error(a);
}
