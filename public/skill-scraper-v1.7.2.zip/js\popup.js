// Skill Scraper - Popup Script
// No login required for scraping, login needed for export

document.addEventListener('DOMContentLoaded', async function () {
    // --- Auth UI Elements ---
    const loginBtn = document.getElementById('loginBtn');
    const authPanel = document.getElementById('authPanel');
    const userInfoBar = document.getElementById('userInfoBar');
    const authArea = document.getElementById('authArea');

    // --- Auth Tabs ---
    document.querySelectorAll('.ss-tab').forEach(tab => {
        tab.addEventListener('click', function () {
            document.querySelectorAll('.ss-tab').forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            const isLogin = this.dataset.tab === 'login';
            document.getElementById('loginForm').style.display = isLogin ? 'flex' : 'none';
            document.getElementById('signupForm').style.display = isLogin ? 'none' : 'flex';
        });
    });

    // --- Login / Sign Up ---
    loginBtn.addEventListener('click', function () {
        chrome.tabs.create({ url: DASHBOARD_URL + "/login?ext=true" });
    });

    // --- Update Auth UI ---
    async function updateAuthUI() {
        try {
            const user = await getCurrentUser();
            if (user) {
                // Logged in
                authArea.innerHTML = `
                    <span class="ss-user-name">${user.email.split('@')[0]}</span>
                    <button id="logoutBtn" class="ss-btn ss-btn-ghost ss-btn-sm">Logout</button>
                `;
                document.getElementById('logoutBtn').addEventListener('click', async () => {
                    await signOut();
                    window.location.reload();
                });

                userInfoBar.style.display = 'flex';
                document.getElementById('userEmail').textContent = user.email;

                // Get plan info
                const plan = await getUserPlan();
                if (plan) {
                    const planConfig = PLANS[plan.plan] || PLANS.free;
                    document.getElementById('planBadge').textContent = planConfig.name;
                    document.getElementById('planBadge').className = 'ss-plan-badge ss-plan-' + plan.plan;
                    const remaining = plan.quota - (plan.used || 0);
                    document.getElementById('usageInfo').textContent =
                        plan.plan === 'enterprise' ? 'Unlimited exports' :
                            `${remaining} exports left`;

                    // Show upgrade link if on free plan
                    if (plan.plan === 'free') {
                        document.getElementById('upgradeLink').style.display = 'flex';
                    }
                }
            } else {
                // Not logged in
                document.getElementById('upgradeLink').style.display = 'none';
            }
        } catch (e) {
            console.log('Auth UI update error:', e);
        }
    }

    // --- Restore session from storage ---
    try {
        const stored = await chrome.storage.sync.get(['supabase_session']);
        if (stored.supabase_session) {
            const sb = getSupabase();
            if (sb) {
                await sb.auth.setSession(stored.supabase_session);
            }
        }
        await updateAuthUI();
    } catch (e) {
        console.log('Session restore error:', e);
    }

    // --- Search Button ---
    document.getElementById('addprofilebtn').addEventListener('click', function () {
        let query = document.getElementById('profileid').value.trim();
        const country = document.getElementById('countrySelect').value;
        const state = document.getElementById('stateInput').value.trim();
        const city = document.getElementById('cityInput').value.trim();

        // Build location string
        const locationParts = [];
        if (city) locationParts.push(city);
        if (state) locationParts.push(state);
        if (country) locationParts.push(country);

        if (locationParts.length > 0) {
            query += ' in ' + locationParts.join(', ');
        }

        const encoded = encodeURIComponent(query);
        window.open(`https://www.google.com/maps/search/${encoded}`);
    });

    // --- Demo Link ---
    document.getElementById('demo_link').addEventListener('click', function (e) {
        e.preventDefault();
        chrome.tabs.create({ url: 'demo.html' });
    });

    // --- Video Link ---
    document.getElementById('demo_video').addEventListener('click', function (e) {
        e.preventDefault();
        chrome.tabs.create({ url: 'https://youtu.be/svsDoqsBt8s' });
    });

    // --- Upgrade Link ---
    document.getElementById('upgradeLink').addEventListener('click', function (e) {
        e.preventDefault();
        chrome.tabs.create({ url: DASHBOARD_URL + '/upgrade' });
    });
});
